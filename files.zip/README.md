# Dashboard de Rotación de Inventario — CL · MX · PE

App en Streamlit que replica la lógica de análisis de rotación trabajada para
Chile, México y Perú: cruce ventas vs stock, rotación, clasificación tipo
semáforo, alertas y recomendaciones comerciales.

## Instalación (una sola vez)

```bash
pip install -r requirements.txt
```

## Ejecutar localmente

```bash
streamlit run app.py
```

Se abre en el navegador (normalmente http://localhost:8501).

## Flujo semanal

1. Exporta de tu sistema los 6 archivos: **stock + ventas** de cada país.
2. En la barra lateral, ajusta **fecha inicio / fin** del período (la app calcula
   los días reales — no asume 7).
3. Sube los archivos en el panel de cada país. Puedes cargar solo uno o los tres.
4. Revisa las 6 secciones (Resumen, Comparativo, Categoría, Producto, Alertas,
   Recomendaciones) y usa los filtros.
5. Descarga el **Excel consolidado** con el botón de arriba para compartir.

## Compartir con el equipo (opcional)

Sube `app.py` y `requirements.txt` a un repo de GitHub y conéctalo a
[Streamlit Community Cloud](https://streamlit.io/cloud) (gratis). Obtienes un
link web que cualquiera del equipo puede abrir.

## Lógica de cálculo

| Métrica | Fórmula |
|---|---|
| Rotación (período) | Venta a costo ÷ Costo de inventario |
| Rotación mensual proyectada | Rotación × (30.44 ÷ días del período) |
| Días de inventario | Stock disp. ÷ (Unidades vendidas ÷ días) |
| % Margen | Margen total ÷ Venta neta |
| Score | Rotación × 0.6 + %margen × 0.4 |
| Capital en riesgo | Σ costo de inventario de NULA + BAJA rotación |

**Clasificación** (sobre rotación mensual proyectada): Estrella ≥2x y margen ≥20% ·
Buena ≥1x · Media 0.3–1x · Baja >0 y <0.3x · Nula sin ventas con stock · Sin stock = 0.

**Alertas:** Producto estancado · Riesgo de quiebre (<7 días con buena rotación) ·
Sobrestock (>180 días, stock >5) · Capital en riesgo.

## Formato de archivos esperado

La app autodetecta la fila de encabezado (0 o 5) y la variante del nombre de la
columna de costo (`Costo neto unitario` / `Costo Neto Unitario`), así que sirve
con los exports de los tres países sin cambios.

**Stock:** Tipo de Producto, Producto, Variante, Stock, Cantidad Disponible,
Costo Neto Prom. Unitario, Costo Neto Prom. Total, Precio Venta Bruto, Último costo.

**Ventas:** Tipo Movimiento, Tipo de Producto / Servicio, Producto / Servicio,
Variante, Cantidad, Costo neto unitario, Costo Total Neto, Venta Total Neta,
Precio Neto Unitario, Margen.
